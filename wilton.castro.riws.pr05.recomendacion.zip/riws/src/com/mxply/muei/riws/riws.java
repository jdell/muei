/* 
 * ***********************************************************
 * MUEI - RIWS - Practice 01: Simple indexing method using Lucene 
 * Author: W. Joel Castro Reynoso
 * Email: joemismito(at)gmail.com
 * ***********************************************************   
 */
package com.mxply.muei.riws;

import com.mxply.muei.riws.commands.RIWSEngine;


public class riws {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		RIWSEngine engine = new RIWSEngine();
		engine.start(args);
	}}
